import React from 'react';
import { Link,  } from 'react-router-dom';
import PropTypes from 'prop-types';
import '../style/font.css';



function Header(props) {

    return (
        <header style={headerStyle}>
            <h3 style={{fontFamily: 'scab'}}> PAUL's SCRABBLE HACK</h3>
            <input style={{fontFamily: "'Comfortaa', cursive",}}type="button" onClick={props.newGame} value="New Game"></input>
            <Link style={linkStye} to="//paulnegedu.com/home" target="_blank"> BACK TO SITE </Link>
            
        </header>
    )
}

const headerStyle = {
    background: '#333',
    color: 'white',
    alignItems: 'center',
    padding: '5px',
    width: '100%',
}
const linkStye ={
    color: '#fff',
    textDecoration: 'none',
    fontSize: '13px',
    fontFamily: "'Comfortaa', cursive",

}

Header.propTypes = {
    newGame: PropTypes.func
}
export default Header

